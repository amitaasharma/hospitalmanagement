radius=int(input("enter the radius"))
area=3.14*radius*radius
print(area)