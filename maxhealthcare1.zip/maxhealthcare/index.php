<?php

$conn = mysqli_connect('localhost:3306','root','','contact_db') or die('connection failed');

if(isset($_POST['submit']))
{
   $name = mysqli_real_escape_string($conn, $_POST['name']);
   $email = mysqli_real_escape_string($conn, $_POST['email']);
   $number = $_POST['number'];
   $date = $_POST['date'];

   $insert = mysqli_query($conn, "INSERT INTO `contact_form`(name, email, number, date) VALUES('$name','$email','$number','$date')") or die('query failed');

   if($insert)
   {
      $message[] = 'appointment made successfully!';
   }
   else
   {
      $message[] = 'appointment failed';
   }

}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hospital website</title>

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="css/style.css">

</head>
<body>
    
<!-- header section starts  -->

<header class="header">

    <a href="#" class="logo"> <i class="fas fa-heartbeat"></i> <strong>MAX</strong>healthcare </a>

    <nav class="navbar">
        <a href="#home">home</a>
        <a href="#about">about</a>
        <a href="#services">services</a>
        <a href="#doctors">doctors</a>
        <a href="#appointment">appointment</a>
        <a href="#review">reviews</a>
        <a href="#blogs">blogs</a>
    </nav>

    <div id="menu-btn" class="fas fa-bars"></div>

</header>

<!-- header section ends -->

<!-- home section starts  -->

<section class="home" id="home">

    <div class="image">
        <img src="image/home-img.svg" alt="">
    </div>

    <div class="content">
        <h3>We take care of your Precious life</h3>
        <p> A person who has a good physical health is likely to have bodily functions and processes working at their peak.</p>
        <a href="#appointment" class="btn"> Book Appointment <span class="fas fa-chevron-right"></span> </a>
    </div>

</section>

<!-- home section ends -->

<!-- icons section starts  -->

<section class="icons-container">

    <div class="icons">
        <i class="fas fa-user-md"></i>
        <h3>150+</h3>
        <p>doctors at work</p>
    </div>

    <div class="icons">
        <i class="fas fa-users"></i>
        <h3>1030+</h3>
        <p>satisfied patients</p>
    </div>

    <div class="icons">
        <i class="fas fa-procedures"></i>
        <h3>490+</h3>
        <p>bed facility</p>
    </div>

    <div class="icons">
        <i class="fas fa-hospital"></i>
        <h3>70+</h3>
        <p>available hospitals</p>
    </div>

</section>

<!-- icons section ends -->

<!-- about section starts  -->

<section class="about" id="about">

    <h1 class="heading"> <span>about</span> us </h1>

    <div class="row">

        <div class="image">
            <img src="image/about-img.svg" alt="">
        </div>

        <div class="content">
            <h3>Gives the world's best quality treatment</h3>
            <p> Max Healthcare is a leading healthcare institution dedicated to providing exceptional medical care and service to our community. With a steadfast commitment to excellence, compassion, and innovation, we strive to improve the health and well-being of every individual we serve.</p>
            <p>Our vision is to be the premier healthcare provider in our region, recognized for our clinical expertise, compassionate care, and commitment to advancing the field of medicine. We aspire to create a healthier community by empowering individuals to achieve optimal health and wellness throughout their lives</p>
            <a href="aboutus.html" class="btn"> learn more <span class="fas fa-chevron-right"></span> </a>
        </div>

    </div>

</section>

<!-- about section ends -->

<!-- services section starts  -->

<section class="services" id="services">

    <h1 class="heading"> our <span>services</span> </h1>

    <div class="box-container">

        <div class="box">
            <i class="fas fa-notes-medical"></i>
            <h3>free checkups</h3>
            <p>Promoting Wellness, One Checkup at a Time: Enjoy Complimentary Health Screenings at Max healthcare</p>
            
        </div>

        <div class="box">
            <i class="fas fa-ambulance"></i>
            <h3>24/7 ambulance</h3>
            <p>Emergency Care Anytime, Anywhere: Our 24/7 Ambulance Service is here to provide swift, expert medical assistance whenever you need it.</p>
            
        </div>

        <div class="box">
            <i class="fas fa-user-md"></i>
            <h3>expert doctors</h3>
            <p>Meet Our Expert Doctors: Leaders in their fields, dedicated to providing the highest level of care and expertise to our patients</p>
            
        </div>

        <div class="box">
            <i class="fas fa-pills"></i>
            <h3>medicines</h3>
            <p>Comprehensive Pharmaceutical Solutions: Empowering Health and Wellness with Trusted Medications</p>
           
        </div>

        <div class="box">
            <i class="fas fa-procedures"></i>
            <h3>bed facility</h3>
            <p>Comfort and Care: Rest easy in our state-of-the-art bed facilities, designed to provide patients with a peaceful and healing environment during their stay            </p>
            
        </div>

        <div class="box">
            <i class="fas fa-heartbeat"></i>
            <h3>total care</h3>
            <p>Comprehensive Care, Complete Wellness: Your Total Health Solution

                
            </p>
           
        </div>

    </div>

</section>

<!-- services section ends -->



<!-- doctors section starts  -->

<section class="doctors" id="doctors">

    <h1 class="heading"> our <span>doctors</span> </h1>

    <div class="box-container">

        <div class="box">
            <img src="image/1dr.jpg" alt="">
            <h3>Dr. Shivani Singla</h3>
            <span>Cardiology</span>
            <div class="share">
            <a href="https://www.facebook.com/" class="fab fa-facebook-f"></a>
                <a href="https://twitter.com/x" class="fab fa-twitter"></a>
                <a href="https://www.instagram.com/" class="fab fa-instagram"></a>
                <a href="https://www.linkedin.com/" class="fab fa-linkedin"></a>
                
            </div>
        </div>

        <div class="box">
            <img src="image/2dr.jpg" alt="">
            <h3>Dr. Tanya Gupta</h3>
            <span>Orthopedics</span>
            <div class="share">
            <a href="https://www.facebook.com/" class="fab fa-facebook-f"></a>
                <a href="https://twitter.com/x" class="fab fa-twitter"></a>
                <a href="https://www.instagram.com/" class="fab fa-instagram"></a>
                <a href="https://www.linkedin.com/" class="fab fa-linkedin"></a>
            </div>
        </div>

        <div class="box">
            <img src="image/doc-3.jpg" alt="">
            <h3>Dr. Akanksha Sharma</h3>
            <span>Intern Doctor</span>
            <div class="share">
            <a href="https://www.facebook.com/" class="fab fa-facebook-f"></a>
                <a href="https://twitter.com/x" class="fab fa-twitter"></a>
                <a href="https://www.instagram.com/" class="fab fa-instagram"></a>
                <a href="https://www.linkedin.com/" class="fab fa-linkedin"></a>
            </div>
        </div>

        <div class="box">
            <img src="image/3dr.jpg" alt="">
            <h3>Dr. Mehak Sharma </h3>
            <span>Neurology</span>
            <div class="share">
            <a href="https://www.facebook.com/" class="fab fa-facebook-f"></a>
                <a href="https://twitter.com/x" class="fab fa-twitter"></a>
                <a href="https://www.instagram.com/" class="fab fa-instagram"></a>
                <a href="https://www.linkedin.com/" class="fab fa-linkedin"></a>
            </div>
        </div>

        <div class="box">
            <img src="image/4dr.jpg" alt="">
            <h3>Dr. Harsh Dhiman</h3>
            <span>Dermatology</span>
            <div class="share">
            <a href="https://www.facebook.com/" class="fab fa-facebook-f"></a>
                <a href="https://twitter.com/x" class="fab fa-twitter"></a>
                <a href="https://www.instagram.com/" class="fab fa-instagram"></a>
                <a href="https://www.linkedin.com/" class="fab fa-linkedin"></a>
            </div>
        </div>

        <div class="box">
            <img src="image/5dr.jpg" alt="">
            <h3>Dr. Manish Sharma</h3>
            <span>Cardiology</span>
            <div class="share">
            <a href="https://www.facebook.com/" class="fab fa-facebook-f"></a>
                <a href="https://twitter.com/x" class="fab fa-twitter"></a>
                <a href="https://www.instagram.com/" class="fab fa-instagram"></a>
                
            
            </div>
        </div>
        <div class="box">
            <img src="image/6dr.jpg" alt="">
            <h3>Dr. Balwinder Singh</h3>
            <span>intern doctor</span>
            <div class="share">
                <a href="https://www.facebook.com/" class="fab fa-facebook-f"></a>
                <a href="https://twitter.com/x" class="fab fa-twitter"></a>
                <a href="https://www.instagram.com/" class="fab fa-instagram"></a>
                
            </div>
        </div>
        <div class="box">
            <img src="image/7dr.jpg" alt="">
            <h3>Dr. Anchal Kumari</h3>
            <span>Oncology</span>
            <div class="share">
            <a href="https://www.facebook.com/" class="fab fa-facebook-f"></a>
                <a href="https://twitter.com/x" class="fab fa-twitter"></a>
                <a href="https://www.instagram.com/" class="fab fa-instagram"></a>
               
            </div>
        </div>
        <div class="box">
            <img src="image/8dr.jpg" alt="">
            <h3>Dr. Raj Kumar</h3>
            <span>Gynaecology</span>
            <div class="share">
            <a href="https://www.facebook.com/" class="fab fa-facebook-f"></a>
                <a href="https://twitter.com/x" class="fab fa-twitter"></a>
                <a href="https://www.instagram.com/" class="fab fa-instagram"></a>
               
            </div>
        </div>

    </div>

</section>

<!-- doctors section ends -->

<!-- appointmenting section starts   -->

<section class="appointment" id="appointment">

    <h1 class="heading"><span>Book</span> your <span>appointment</span> now </h1>    

    <div class="row">

        <div class="image">
            <img src="image/appointment-img.svg" alt="">
        </div>

        <form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post">
        <?php
            if(isset($message)) 
            {
                foreach($message as $message) 
            {
                echo'<p class ="message">'.$message.'</p>';
            }
            }
        ?>
      
            <h3>Book Appointment</h3>
            <input type="text"name="name" placeholder="Your Name" class="box">
            <input type="number"name="number" placeholder="Your Mobile number" class="box">
            <input type="email"name="email" placeholder="Your email" class="box">
            <input type="date"name="date" class="box">
            
            
            <input type="submit" name="submit" value="Book Appointment" class="btn">
        </form>

    </div>

</section>

<!-- appointmenting section ends -->

<!-- review section starts  -->

<section class="review" id="review">
    
    <h1 class="heading"> Patient's <span>reviews</span> </h1>

    <div class="box-container">

        <div class="box">
            <img src="image/sanj.jpg" alt="">
            <h3>Sanjana Jamnal</h3>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <p class="text">I recently had the privilege of being a patient at Max Healthcare, and I cannot praise the staff and facilities enough. From the moment I arrived, I was greeted with warmth and compassion. The doctors and nurses went above and beyond to ensure that I received the best possible care. They took the time to listen to my concerns, explain my treatment options, and answer all of my questions with patience and understanding. 
                
                I am incredibly grateful for the exceptional care I received at Max Healthcare. Thanks to the skilled and compassionate team, I am now on the road to recovery. I highly recommend Max Healthcare to anyone in need of medical care. Thank you for everything!" </p>
        </div>

        <div class="box">
            <img src="image/pushpa,jpg.jpg" alt="">
            <h3>Pushpa Rai</h3>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <p class="text">My experience at Max Healthcare was nothing short of exceptional. From the moment I walked through the doors, I was impressed by the professionalism and kindness of the staff. The doctors, nurses, and support staff demonstrated a genuine commitment to patient care, and their expertise and dedication were evident in every interaction.

                Not only did Max Healthcare provide me with top-notch medical treatment, but they also took the time to address my emotional needs and provide support during a challenging time. I felt truly cared for and supported throughout my entire journey.</p>
        </div>

        <div class="box">
            <img src="image/amita.jpg" alt="">
            <h3>Amita Sharma</h3>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <p class="text">I recently had the privilege of receiving care at Max Healthcare, and I cannot express enough gratitude for the outstanding service I received. From the moment I entered the hospital, I was greeted with warmth and professionalism. The staff members, from the receptionists to the nurses and doctors, made me feel like family, and their genuine concern for my well-being was evident in every interaction.

                I am immensely grateful to the entire team at Max Healthcare for their compassion, professionalism, and commitment to excellence. They are true healthcare heroes, and I would recommend Max Healthcare to anyone in need of exceptional medical care
            </p>
        </div>

    </div>

</section>

<!-- review section ends -->

<!-- blogs section starts  -->

<section class="blogs" id="blogs">

    <h1 class="heading"> our <span>blogs</span> </h1>

    <div class="box-container">

        <div class="box">
            <div class="image">
                <img src="image/blog-1.jpg" alt="">
            </div>
            <div class="content">
                <div class="icon">
                    <a href="#"> <i class="fas fa-calendar"></i> 01 April, 2024 </a>
                    <a href="#"> <i class="fas fa-user"></i> by Amita Sharma </a>
                </div>
                <h3>Mayo Clinic</h3>
                <p>The blog has a "Sharing" feature that cover topics like diseases,treatment,research anddiagnosis. This information can be used by doctors,researchers and patients aroundthe world</p>
                <a href="mayo.html" class="btn"> learn more <span class="fas fa-chevron-right"></span> </a>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="image/blog-2.jpg" alt="">
            </div>
            <div class="content">
                <div class="icon">
                    <a href="#"> <i class="fas fa-calendar"></i> 21 March, 2024 </a>
                    <a href="#"> <i class="fas fa-user"></i> by Max healthcare </a>
                </div>
                <h3>Medgadget</h3>
                <p>The blog reports on major healthcare conference and conducts interview with medical technology leaders. </p>
                <a href="medgadget.html" class="btn"> learn more <span class="fas fa-chevron-right"></span> </a>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="image/blog-3.jpg" alt="">
            </div>
            <div class="content">
                <div class="icon">
                    <a href="#"> <i class="fas fa-calendar"></i> 19 March, 2024 </a>
                    <a href="#"> <i class="fas fa-user"></i> by Dr Raj Kumar </a>
                </div>
                <h3>Medical Xpress</h3>
                <p>This website consistently provides research reports and health news, and headlines can be sorted by popularity or recency</p>
                <a href="medxpress.html" class="btn"> learn more <span class="fas fa-chevron-right"></span> </a>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img src="image/blog-4.jpg" alt="">
            </div>
            <div class="content">
                <div class="icon">
                    <a href="#"> <i class="fas fa-calendar"></i> 16 March, 2024 </a>
                    <a href="#"> <i class="fas fa-user"></i> by Max healthcare </a>
                </div>
                <h3>Everyday health</h3>
                <p>The blog provides information about health tips and tricks to help people live healthier lives
                    
                </p>
                <a href="everhealth.html" class="btn"> learn more <span class="fas fa-chevron-right"></span> </a>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img src="image/blog-5.jpg" alt="">
            </div>
            <div class="content">
                <div class="icon">
                    <a href="#"> <i class="fas fa-calendar"></i> 01 March, 2024 </a>
                    <a href="#"> <i class="fas fa-user"></i> by Max Healthcare</a>
                </div>
                <h3>Patients Testimonials</h3>
                <p>In the realm of healthcare, patient testimonials serve as powerful narratives, shedding light on the human experiences behind medical treatments. </p>
                <a href="patienttest.html" class="btn"> learn more <span class="fas fa-chevron-right"></span> </a>
            </div>
        </div>
        
            
        </div>

    </div>

</section>

<!-- blogs section ends -->

<!-- footer section starts  -->

<section class="footer">

    <div class="box-container">

        <div class="box">
            <h3>quick links</h3>
            <a href="#home"> <i class="fas fa-chevron-right"></i> home </a>
            <a href="#about"> <i class="fas fa-chevron-right"></i> about </a>
            <a href="#services"> <i class="fas fa-chevron-right"></i> services </a>
            <a href="#doctors"> <i class="fas fa-chevron-right"></i> doctors </a>
            <a href="#appointment"> <i class="fas fa-chevron-right"></i> appointment </a>
            <a href="#review"> <i class="fas fa-chevron-right"></i> review </a>
            <a href="#blogs"> <i class="fas fa-chevron-right"></i> blogs </a>
        </div>

        <div class="box">
            <h3>our services</h3>
            <a href="dentalcare.html"> <i class="fas fa-chevron-right"></i> Dental care </a>
            <a href="gynaec.html"> <i class="fas fa-chevron-right"></i> Obstetrics and Gynaecology </a>
            <a href="cardio.html"> <i class="fas fa-chevron-right"></i> cardiology </a>
            <a href="neurology.html"> <i class="fas fa-chevron-right"></i> Neurosurgeon </a>
            <a href="ambulance.html"> <i class="fas fa-chevron-right"></i> Ambulance service </a>
        </div>

        <div class="box">
            <h3>appointment info</h3>
            <a href="#"> <i class="fas fa-phone"></i> 6284775210 </a>
            <a href="https://mail.google.com/mail/u/0/#inbox?compose=GTvVlcSPFdPmQvtRpGHNxSVXKsnsfQTgtWJHnNkpdBMMLxMLthpZcvXFnGGpXxXjqTtPxlDRrMtTg"> <i class="fas fa-envelope"></i> maxhealthcare@gmail.com </a>
            <a href="https://www.google.com/maps/dir//Max+Super+Specialty+Hospital,+Mohali,+Chandigarh+Rd,+near+Civil+Hospital,+Phase+6,+Mo,+Chandigarh,+Punjab+160055/@30.7390785,76.5708636,12z/data=!4m8!4m7!1m0!1m5!1m1!1s0x390fee144e36fcd5:0xa254c2b1f858248a!2m2!1d76.7150592!2d30.7390785?entry=ttu"> <i class="fas fa-map-marker-alt"></i> Chandigarh,India </a>
        </div>

        <div class="box">
            <h3>follow us on</h3>
            <a href="https://twitter.com/"> <i class="fab fa-twitter"></i> twitter </a>
            <a href="https://www.instagram.com/"> <i class="fab fa-instagram"></i> instagram </a>
            <a href="https://www.linkedin.com/"> <i class="fab fa-linkedin"></i> linkedin </a>
            <a href="https://in.pinterest.com/"> <i class="fab fa-pinterest"></i> pinterest </a>
        </div>

    </div>

    <h1 class="credit"> created by <span>&copy;MAX</span> healthcare | all rights reserved! </h1>

</section>

<!-- footer section ends -->


<!-- js file link  -->
<script src="js/script.js"></script>

</body>
</html>

